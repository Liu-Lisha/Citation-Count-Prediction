from load import loadPrepareData
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.autograd import Variable
from model import MyModel
import time
from evaluate import evaluate


def batchify(data):
	abstract, reviews, wide, citation = data
	print(len(abstract), len(reviews), len(wide), len(citation))
	data = []
	for i in range(len(abstract)):
		buf = torch.tensor(abstract[i]), torch.tensor(reviews[i]), torch.tensor(wide[i]), torch.tensor(citation[i])
		data.append(buf)
	return data


def trainIters(corpus, learning_rate, lr_decay_epoch, lr_decay_ratio, batch_size, 
				hidden_size, embed_size, save_dir, loadFilename=None):
	
	print("corpus={}, learning_rate={}, lr_decay_epoch={}, lr_decay_ratio={}, batch_size={}, \
	hidden_size={}, embed_size={}, save_dir={}".format(corpus, learning_rate, \
	lr_decay_epoch, lr_decay_ratio, batch_size, hidden_size, embed_size, save_dir))

	print('load data...')
	vocab, train_data, test_data = loadPrepareData(corpus)
	print('finish loading data...')

	weight = torch.zeros(vocab.vocab_size, embed_size).cuda()
	for i in range(len(vocab.idx2word)):
		if i != 0:
			word = vocab.idx2word[i]
			weight[i, :] = torch.from_numpy(vocab.model[word]).cuda()

	train_set = batchify(train_data)
	test_set = batchify(test_data)

	net = MyModel(vocab_size=vocab.vocab_size, embed_size=embed_size, weight=weight, q=16, l=3, sentlen=25)
	net = net.cuda()
	loss_function = nn.MSELoss()
	optimizer = optim.SGD(net.parameters(), lr=learning_rate)

	dir = '../res/' + corpus + '/out'
	fout = open(dir, 'w')
	epoch = 0

	while(1):
		epoch += 1
		start = time.time()
		train_loss, test_loss = 0, 0
		best_loss = 1000
		n, m = 0, 0
		for data in train_set:
			abstract = data[0]
			review = data[1]
			wide = data[2]
			citation = data[3]

			n += 1
			net.zero_grad()
			abstract = Variable(abstract).cuda()
			review = Variable(review).cuda()
			citation = Variable(citation).cuda()
			wide = Variable(wide).cuda()

			predict = net(abstract, review, wide)
			loss = loss_function(predict, citation)
			loss.backward()
			optimizer.step()
			train_loss += loss.data
			if n % 100 == 0:
				print("n: %d" % n)
		
		print("train end!")

		with torch.no_grad():
			m = 0
			test_loss = 0
			y = []
			predicts = []
			#citations = []
			#predicts = []
			for data in test_set:
				m += 1
				abstract = data[0]
				review = data[1]
				citation = data[3]
				wide = data[2]
				y.append(citation.data)
				#fout.write("y:%.4f " % citation.data)
				#print(n)
				#print(citation)
				#print(np.array(abstract).shape)
				abstract = Variable(abstract).cuda()
				review = Variable(review).cuda()
				citation = Variable(citation).cuda()
				wide = Variable(wide).cuda()

				predict = net(abstract, review, wide)
				predicts.append(predict.data)
				#fout.write("predict:%.4f\n" % predict.data)
				#print(predict)

				loss = loss_function(predict, citation)
				test_loss += loss.data

				if m % 100 == 0:
					print(m)
			print("test end!")
			evaluate(y, predicts, fout)

		end = time.time()
		runtime = end - start

		if test_loss < best_loss:
			best_loss = test_loss
			dir = '../model/' + corpus + '/model.pkl'
			torch.save(net.state_dict(), dir)

		fout.write("epoch: %d, train loss: %.4f, test loss: %.4f, time: %.2f\n" % (epoch, train_loss.data/n, test_loss.data/m, runtime))
		print("epoch: %d, train loss: %.4f, test loss: %.4f, time: %.2f" % (epoch, train_loss.data/n, test_loss.data/m, runtime))
		
	fout.close()
