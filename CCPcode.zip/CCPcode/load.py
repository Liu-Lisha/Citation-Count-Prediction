from gensim.models.word2vec import Word2Vec
import os
import numpy as np

class Vocabulary:
	def __init__(self, corpus):
		self.corpus = corpus
		w2vpath = '../model/w2vmodel'
		self.model = Word2Vec.load(w2vpath)
		self.vocab = self.model.wv.vocab
		self.vocab_size = len(self.vocab) + 1
		self.word2idx = {word: i+1 for i, word in enumerate(self.vocab)}
		self.word2idx['<unk>'] = 0
		self.idx2word = {i+1: word for i, word in enumerate(self.vocab)}
		self.idx2word[0] = '<unk>'

def loadData(corpus, type):
	path = '../data/' + corpus + '/' + type + '/'

	#load abstract...
	dir = path + 'abstract.txt'
	with open(dir, 'r') as f:
		lines = f.readlines()
	abstracts = [line.strip().split('\t')[1:] for line in lines]
	abstracts = [ [sent.split(' ') for sent in abstract] for abstract in abstracts]
	#print(abstracts[:1])

	#load reviews...
	rpath = path + 'review/'
	dirs = os.listdir(rpath)
	dirs.sort()
	reviews = []
	for dir in dirs:
		fdir = rpath + dir
		with open(fdir, 'r') as f:
			lines = f.readlines()
		review = []
		for line in lines:
			review.append(line.strip().split('\t'))
		reviews.append(review)

	print(len(reviews))
	reviews = [ [ [sent.split(' ') for sent in reviewer] for reviewer in review] for review in reviews]
	#print(reviews[:3])

	#load wide features...
	dir = path + 'features.txt'
	dimension = 104
	wide_features = np.loadtxt(dir, delimiter = "\t", usecols = np.arange(2, dimension + 2))

	#load citation...
	dir = path + 'citation.txt'
	with open(dir, 'r') as f:
		lines = f.readlines()
	citation = []
	for line in lines:
		citation.append(float(line.strip()))

	return abstracts, reviews, wide_features, citation

def encode_abstract(vocab, tokenized_samples):
	features = []
	paper_num = 0
	for sample in tokenized_samples:
		#paper_num += 1
		
		#sent_num = 0
		feature = []
		for sent in sample:
			#sent_num += 1
			
			#token_num = 0
			sent_feature = []
			for token in sent:
				#token_num += 1
				#print(paper_num,sent_num,token_num)
				#print(token)
				if token == "":
					continue
				if token not in vocab.word2idx:
					token = '<unk>'
				sent_feature.append(vocab.word2idx[token])
			if not sent_feature:
				continue
			feature.append(sent_feature)
		features.append(feature)

	#print(features[:5])
	#print(vocab.idx2word[features[0][0][0]])
	#print(vocab.idx2word[features[0][0][1]])

	return features

def encode_review(vocab, tokenized_samples):
	features = []
	paper_num = 0
	for sample in tokenized_samples:
		#paper_num += 1
		
		#sent_num = 0
		feature = []
		for reviewer in sample:
			#sent_num += 1
			
			#token_num = 0
			reviewer_feature = []
			for sent in reviewer:
				sent_feature = []
				for token in sent:
				#token_num += 1
				#print(paper_num,sent_num,token_num)
				#print(token)
					if token == "":
						continue
					if token not in vocab.word2idx:
						token = '<unk>'
					sent_feature.append(vocab.word2idx[token])
				if not sent_feature:
					continue
				#print("sent_feature")
				#print(len(sent_feature))
				#print(sent_feature)
				reviewer_feature.append(sent_feature)
			#print(reviewer_feature)
			feature.append(reviewer_feature)
		features.append(feature)

	#print(features[:3])
	#print(vocab.idx2word[features[0][0][0][0]])
	#print(vocab.idx2word[features[0][0][0][1]])
	return features

def pad_abstract(features, maxlen=50, PAD=0):
	padded_features = []
	for feature in features:
		padded_feature = []
		for sent in feature:
			if len(sent) >= maxlen:
				padded_sent = sent[:maxlen]
			else:
				padded_sent = sent
				while(len(padded_sent) < maxlen):
					padded_sent.append(PAD)
			padded_feature.append(padded_sent)
		padded_features.append(padded_feature)
	return padded_features

def pad_review(features, maxsents=50, maxwords=50, PAD=0):
	padded_features = []
	for feature in features:
		padded_feature = []
		for reviewer in feature:
			buf_reviewer = []
			for sent in reviewer:
				if len(sent) > maxwords:
					padded_sent = sent[:maxwords]
				else:
					padded_sent = sent
					while(len(padded_sent) < maxwords):
						padded_sent.append(PAD)
				buf_reviewer.append(padded_sent)

			if len(buf_reviewer) >= maxsents:
				padded_reviewer = buf_reviewer[:maxsents]
			else:
				padded_reviewer = buf_reviewer
				while(len(padded_reviewer) < maxsents):
					_list = []
					for i in range(maxwords):
						_list.append(PAD)
					padded_reviewer.append(_list)

			padded_feature.append(padded_reviewer)
		padded_features.append(padded_feature)
	return padded_features


def prepareData(vocab, corpus, type):
	path = '../data/' + corpus + '/' + type + '/'
	#print(os.listdir(path))
	#loading and tokenizing...
	tokenized_abstract, tokenized_review, wide_features, citation = loadData(corpus, type)
	print(len(tokenized_abstract), len(tokenized_review), len(wide_features), len(citation))
	#encoding...
	abstract_features = encode_abstract(vocab, tokenized_abstract)
	review_features = encode_review(vocab, tokenized_review)
	#print(len(abstract_features), len(review_features), len(wide_features))
	#padding...
	padded_abstract = pad_abstract(abstract_features, maxlen=25)
	padded_review = pad_review(review_features, maxwords=25)
	#print(len(padded_abstract), len(padded_review), len(wide_features))

	data = [padded_abstract, padded_review, wide_features, citation]
	return data


def loadPrepareData(corpus):
	vocab = Vocabulary(corpus)
	print(vocab.vocab_size)
	train_data = prepareData(vocab, corpus, 'train')
	test_data = prepareData(vocab, corpus, 'test')
	print(len(train_data))
	return vocab, train_data, test_data
