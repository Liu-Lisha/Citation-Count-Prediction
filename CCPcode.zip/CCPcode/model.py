import torch
from torch import nn
from torch.autograd import Variable
import torch.nn.functional as F


class MLP(nn.Module):
	def __init__(self, in_features, out_features):
		super(MLP, self).__init__()
		self.linear = nn.Linear(in_features, out_features)
		self.tanh = nn.Tanh()

	def forward(self, x):
		x = self.tanh(self.linear(x))
		x = x.view(1,-1)
		return x


class CNN(nn.Module):
	def __init__(self, in_channel, out_channel, kernel_size, sentlen):
		super(CNN, self).__init__()
		self.sentlen = sentlen
		self.out_channel = out_channel
		self.conv = nn.Conv2d(in_channel, out_channel, kernel_size)
		self.tanh = nn.Tanh()
		self.maxpool = nn.MaxPool2d(kernel_size=(self.sentlen-2,1))

	def forward(self, x):
		x = self.tanh(self.conv(x))
		x = self.maxpool(x)
		x = x.view(-1,self.out_channel)
		#print(x.shape)
		return x


class BiLSTM(nn.Module):
	def __init__(self, input_dim, hidden_dim, dropout=0):
		super(BiLSTM, self).__init__()
		self.num_layers = 1
		self.bi_num = 2
		self.hidden_dim = hidden_dim
		self.dropout = nn.Dropout(0.2)
		self.rnn = nn.GRU(input_size=input_dim, hidden_size=hidden_dim, dropout=dropout, bidirectional=True, batch_first=True)
		self.fc = MLP(hidden_dim*2, hidden_dim)

	def init_hidden(self, batch_size):
		return torch.zeros(self.num_layers*self.bi_num,batch_size,self.hidden_dim).cuda()

	def forward(self, X):
		h = self.init_hidden(batch_size=1)
		H = []
		X = X.view(1,X.shape[0],-1)#(batch,seqlen,dim)
		X = self.dropout(X)
		out, h = self.rnn(X, h)
		#out(batch, seq_len, num_directions * hidden_size)
		#h.shape(2,num_layers * num_directions, batch, hidden_size)
		h1 = out.view(1, X.shape[1], 2, self.hidden_dim)[0][-1][0]
		h2 = out.view(1, X.shape[1], 2, self.hidden_dim)[0][0][1]
		#print("h1")
		#print(h1.shape)
		h = torch.cat((h1,h2),0)
		h = self.fc(h)
		#print("h.shape")
		#print(h.shape)
		return h

class Encoder(nn.Module):
	def __init__(self, input_dim, hidden_dim, dropout=0):
		super(Encoder, self).__init__()
		self.num_layers = 1
		self.bi_num = 2
		self.hidden_dim = hidden_dim
		self.dropout = nn.Dropout(0.2)
		self.rnn = nn.GRU(input_size=input_dim, hidden_size=hidden_dim, bidirectional=True, batch_first=True)

	def init_hidden(self, batch_size):
		return torch.zeros(self.num_layers*self.bi_num,batch_size,self.hidden_dim).cuda()

	def forward(self, X):
		
		bsz = X.size(0)
		h = self.init_hidden(batch_size=bsz)
		H = []
		#X = X.view(1,X.shape[0],-1)#(batch,seqlen,dim)
		X = self.dropout(X)
		out, h = self.rnn(X, h)
		
		#out(batch, seq_len, num_directions * hidden_size)
		#h.shape(2,num_layers * num_directions, batch, hidden_size)
		out = out.view(bsz, -1, 2, self.hidden_dim)
		out = out.transpose(0,2)#out(num_directions, seq_len, batch, hidden_size)
		h1 = out[0][-1]
		h2 = out[1][0]
		#print("h1")
		#print(h1.shape)
		h = torch.cat((h1,h2),1)
		#print("h.shape")
		#print(h.shape)
		return h

class Attention(nn.Module):
	def __init__(self):
		super(Attention, self).__init__()
		self.softmax = nn.Softmax()

	def forward(self, A, X):
		A = self.softmax(A)
		p = 0
		for i in range(len(A)):
			p += A[i] * X[i]
		return p

class OutLayer(nn.Module):
	def __init__(self):
		super(OutLayer, self).__init__()
		self.linear1 = nn.Linear(104, 32)
		self.linear2 = nn.Linear(32, 1)
		self.tanh1 = nn.Tanh()
		self.tanh2 = nn.Tanh()

	def forward(self, wide, deep):
		wide = wide.float()
		#print(deep.shape)
		#print(wide.shape)
		features = torch.cat([wide, deep], 0)
		out = self.tanh1(self.linear1(features))
		out = self.tanh2(self.linear2(out))
		return out

class Review_Abstract_Match(nn.Module):
	def __init__(self, d_sent, hidden):
		super(Review_Abstract_Match, self).__init__()
		self.d_sent = d_sent
		self.linear_a = nn.Linear(d_sent, hidden)
		self.linear_r = nn.Linear(d_sent, hidden)
		self.linear_h = nn.Linear(2*d_sent, hidden)
		self.linear_g = nn.Linear(hidden, 1)
		self.tanh = nn.Tanh()
		
		self.attention = Attention()
		self.gated_linear = nn.Linear(2*d_sent, 2*d_sent)
		self.dropout = nn.Dropout(0.5)
		self.rnn = nn.GRUCell(2*d_sent, 2*d_sent)
		self.linear = nn.Linear(4*d_sent,d_sent)

	def forward(self, reviews, abstracts):
		#print("reviews shape: ")
		#print(reviews.shape)
		#print("abstracts shape: ")
		#print(abstracts.shape)
		u0 = torch.zeros(1, 2*self.d_sent).cuda()
		U = []
		U.append(u0)
		t = 0
		#print("reviews")
		#print(reviews)
		for review_sent in reviews:
			t += 1
			#print("t:")
			#print(t)
			H = []
			for abstract_sent in abstracts:
				w_a = self.linear_a(abstract_sent)
				w_r = self.linear_r(review_sent)
				w_h = self.linear_h(U[t-1].squeeze(0))
				G = self.tanh(w_a + w_r +w_h)
				w_g = self.linear_g(G)
				#print("review_sent")
				#print(review_sent)
				H.append(w_g)
			H = torch.cat(H, 0)
			c = self.attention(H, abstracts)
			x = torch.cat([review_sent,c],0)
			gate = torch.sigmoid(self.gated_linear(x))
			x = gate * x
			x = x.unsqueeze(0)
			x = self.dropout(x)
			ut = self.rnn(x, U[t-1])
			U.append(ut)
		U = torch.cat(U, 0)
		U = U[1:]
		#U = self.linear(U)
		#print("X.shape")
		#print(X.shape)
		#U = self.linear(U)
		#print("U.shape")
		#print(U.shape)
		#u0 = torch.zeros(1, 2*self.d_sent).cuda()
		U_reverse = []
		U_reverse.append(u0)
		t = 0
		
		for i in range(len(reviews)-1,-1,-1):
			review_sent = reviews[i]
			t += 1
			#print("t:")
			#print(t)
			H = []
			for abstract_sent in abstracts:
				w_a = self.linear_a(abstract_sent)
				w_r = self.linear_r(review_sent)
				w_h = self.linear_h(U_reverse[t-1].squeeze(0))
				G = self.tanh(w_a + w_r +w_h)
				w_g = self.linear_g(G)
				#print("review_sent")
				#print(review_sent)
				H.append(w_g)
			H = torch.cat(H, 0)
			c = self.attention(H, abstracts)
			review_sent = review_sent.view(self.d_sent)
			x = torch.cat([review_sent,c],0)
			x = x.unsqueeze(0)
			ut_1 = U_reverse[t-1]
			x = self.dropout(x)
			ut = self.rnn(x, U_reverse[t-1])
			U_reverse.append(ut)
		U_reverse = torch.cat(U_reverse, 0)
		U_reverse = U_reverse[1:]
		#U_reverse = self.linear(U_reverse)

		U_right = []
		for i in range(len(reviews)-1,-1,-1):
			U_right.append(U_reverse[i].unsqueeze(0))
		U_right = torch.cat(U_right, 0)

		U = torch.cat([U, U_reverse], 1)
		U = self.linear(U)
		
		return U

class Review_Abstract_Match3(nn.Module):
	def __init__(self, d_sent, hidden):
		super(Review_Abstract_Match, self).__init__()
		self.d_sent = d_sent
		self.linear_a = nn.Linear(d_sent, hidden)
		self.linear_r = nn.Linear(d_sent, hidden)
		self.linear_g = nn.Linear(hidden, 1)
		self.tanh = nn.Tanh()
		
		self.attention = Attention()
		self.dropout = nn.Dropout(0.5)
		self.rnn = nn.GRU(2*d_sent, d_sent, bidirectional=True)
		self.linear = nn.Linear(200,100)

	def forward(self, reviews, abstracts):
		#print("reviews shape: ")
		#print(reviews.shape)
		#print("abstracts shape: ")
		#print(abstracts.shape)
		u0 = torch.zeros(2,1,self.d_sent).cuda()
		
		#print("reviews")
		#print(reviews)
		X = []
		for review_sent in reviews:
			#print("t:")
			#print(t)
			H = []
			for abstract_sent in abstracts:
				w_a = self.linear_a(abstract_sent)
				w_r = self.linear_r(review_sent)
				G = self.tanh(w_a + w_r)
				w_g = self.linear_g(G)
				#print("review_sent")
				#print(review_sent)
				H.append(w_g)
			H = torch.cat(H, 0)
			c = self.attention(H, abstracts)
			review_sent = review_sent.view(self.d_sent)
			x = torch.cat([review_sent,c],0)
			x = x.view(1,1,-1)
			X.append(x)
			#print("input.shape")
			#print(input.shape)
		X = torch.cat(X, 0)
		#print("X.shape")
		#print(X.shape)
		X = self.dropout(X)
		U, hidden = self.rnn(X, u0)
		U = U.view(-1, self.d_sent*2)
		U = self.linear(U)
		#print("U.shape")
		#print(U.shape)
		
		return U


class Self_Match(nn.Module):
	def __init__(self, d_sent, hidden):
		super(Self_Match, self).__init__()
		self.d_sent = d_sent
		self.linear_r = nn.Linear(d_sent, hidden)
		self.linear_r2 = nn.Linear(d_sent, hidden)
		self.tanh = nn.Tanh()
		self.linear_g = nn.Linear(hidden, 1)
		self.attention = Attention()
		self.gated_linear = nn.Linear(2*d_sent, 2*d_sent)
		self.dropout = nn.Dropout(0.5)
		self.rnn = nn.GRU(2*d_sent, d_sent, bidirectional=True, batch_first=True)
		self.linear = nn.Linear(4*d_sent, d_sent)

	def forward(self, U):
		v0 = torch.zeros(2, 1, self.d_sent).cuda()
		X= []
		for u_t in U:
			H = []
			for u_j in U:
				w_uj = self.linear_r(u_j)
				w_ut = self.linear_r2(u_t)
				G = self.tanh(w_uj + w_ut)
				w_g = self.linear_g(G)

				H.append(w_g)
			H = torch.cat(H, 0)
			c = self.attention(H, U)
			x = torch.cat([u_t, c],0)
			gate = torch.sigmoid(self.gated_linear(x))
			x = gate * x
			x = x.view(1,1,-1)
			X.append(x)
			#gate = torch.sigmoid(self.W_g.mm(cnew))
			#v = gate.mul(cnew)
			#v = v.view(-1)
			
		X = torch.cat(X,1)
		X = self.dropout(X)
		out, hidden = self.rnn(X, v0)
		V = torch.cat([out[0][0], out[0][-1]], 0)
		V = self.linear(V)
		return V

class Review_Attention(nn.Module):
	def __init__(self):
		super(Review_Attention, self).__init__()
		self.attention = Attention()

	def forward(self, e_paras):
		e_news = []
		n = len(e_paras)
		for i in range(n):
			scores = []
			for j in range(n):
				if i == j:
					s = torch.zeros(1).cuda()
				else:
					s = e_paras[i].matmul(e_paras[j])
				#s = e_paras[i].matmul(e_paras[j]) if i != j else torch.zeros(1).cuda()
				s = s.view(1,1)
				scores.append(s)
			scores = torch.cat(scores, 0)
			scores = scores.view(-1)
			e_new = self.attention(scores, e_paras)
			e_new = e_new.view(1, -1)
			e_news.append(e_new)
		e_news = torch.cat(e_news, 0)
		return e_news

class Cross_Reviews(nn.Module):
	def __init__(self, d):
		super(Cross_Reviews, self).__init__()
		self.dim = d
		self.review_attention = Review_Attention()
		self.fc = nn.Linear(3*d, d)

	def forward(self, reviews):
		n = len(reviews)
		v_orths = []
		v_paras = []
		for i in range(n):
			vi = reviews[i]

			vo = torch.zeros(self.dim).cuda()
			for j in range(n):
				if j == i:
					continue
				vo += reviews[j]
			vo /= n - 1

			buf1 = vi.matmul(vo)
			buf2 = vo.matmul(vo)
			
			v_para = buf1 / buf2 * vo
			v_orth = vi - v_para
			v_para = v_para.unsqueeze(0)
			v_orth = v_orth.unsqueeze(0)
			v_paras.append(v_para)
			v_orths.append(v_orth)
		v_paras = torch.cat(v_paras, 0)
		v_orths = torch.cat(v_orths, 0)

		v_paras2 = self.review_attention(v_paras)

		e = torch.cat([v_orths, v_paras, v_paras2], 1)
		e = self.fc(e)
		return e


class MyModel(nn.Module):
	def __init__(self, vocab_size, embed_size, weight, q, l, sentlen):
		super(MyModel, self).__init__()
		self.embedding = nn.Embedding.from_pretrained(weight)
		self.embedding.weight.requires_grad = True
		self.sentlen = sentlen
		self.embed_size = embed_size
		self.q = q
		self.cnn = CNN(1, q, kernel_size=(l, embed_size), sentlen=sentlen)
		self.encoder = Encoder(embed_size, q)
		self.review_abstract_match = Review_Abstract_Match(q, 32)
		
		self.self_match = Self_Match(q, 32)
		self.bilstm = BiLSTM(q, q)
		self.cross_reviews = Cross_Reviews(q)

		self.mlp = MLP(103, 32)
		#self.softmax = Softmax(50, 3)
		self.mlp2 = MLP(q, 1)
		#self.mlp2 = MLP(64, 1)
		self.mlp3 = MLP(32, 32)
		
		
		self.outlayer = OutLayer()


	def forward(self, abstract, review, wide):
		#print("begin!")
		abstract_embeddings = self.embedding(abstract)
		review_embeddings = self.embedding(review)
		#print("review_embeddings")
		#print(review_embeddings.data)

		#print(review[0].shape)

		'''
		abstract_sents = self.encoder(abstract_embeddings)
		reviewers = []
		for reviewer in review_embeddings:
			review_sents = self.encoder(reviewer)
			reviewers.append(review_sents)
		'''
		
		abstract_sents = abstract_embeddings.view(-1,1,self.sentlen,self.embed_size)
		abstract_sents = self.cnn(abstract_sents)
		

		reviewers = []
		for reviewer in review_embeddings:
			review_sents = reviewer.view(-1,1,self.sentlen,self.embed_size)
			review_sents = self.cnn(review_sents)
			reviewers.append(review_sents)
		

		reviews = []
		#print("abstract")
		#print(abstract_sents)
		for reviewer in reviewers:
			U = self.review_abstract_match(reviewer, abstract_sents)
			#e_review = self.self_match(reviewer)
			e_review = self.bilstm(U)

			#print("e_review.shape")
			#print(e_review.shape)
			#print(e_review)
			e_review = e_review.view(1,-1)
			reviews.append(e_review)
		reviews = torch.cat(reviews, 0)
		#print("buf.shape")
		#print(buf.shape)

		reviews = self.cross_reviews(reviews)

		res = torch.zeros(self.q).cuda()
		for i in reviews:
			res += i
		res /= len(reviews)
		
		#res = self.mlp(res)

		#res = res.view(-1)
		wide = wide.float()

	
		#features = torch.cat([wide, res], 0)
		

		res = self.outlayer(wide, res)
		#res = self.mlp3(res)
		return res