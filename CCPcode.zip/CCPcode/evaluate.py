from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
import numpy as np

def spearman_rank(y_test, result):
	# the data sets to be ranked
	set_1 = y_test.copy()
	set_2 = result.copy()

	# order the sets
	set_1_ord = sorted(set_1)
	set_2_ord = sorted(set_2)

	# append relevant rank to each value in set
	set_1_ranked = []
	set_2_ranked = []

	for i in range(len(set_1)):
		set_1_ranked.append([set_1[i], set_1_ord.index(set_1[i])+1])

	for i in range(len(set_2)):
		set_2_ranked.append([set_2[i], set_2_ord.index(set_2[i])+1])

	#print set_1_ranked
	#print set_2_ranked

	# calculate d
	d = []
	for i in range(len(set_1_ranked)):
		d.append(set_1_ranked[i][1] - set_2_ranked[i][1])
	#print d

	# calculate d^2
	d_sq = [i**2 for i in d]
	#print d_sq

	# sum d^2
	sum_d_sq = sum(d_sq)
	#print sum_d_sq

	# calculate n^3 - n
	n_cu_min_n = len(set_1)**3 - len(set_1)
	#print n_cu_min_n

	# calculate r
	r = 1 - ((6.0*sum_d_sq)/n_cu_min_n)
	print("spearman_rank: %f" % r)


def prepare(y_list, pre_list):
	y = y_list.copy()
	pre = pre_list.copy()
	y_id = []
	pre_id = []
	cita = []

	f = open("topn.txt", 'w')
	f.write("y:\n")
	for i in range(len(y)):
		_max = max(y)
		id = y.index(_max)
		f.write("%d, %.4f\n" % (id, _max))
		y_id.append(id)
		cita.append(_max)
		y[id] = -100
	f.write("predict:\n")
	for i in range(len(pre)):
		_max = max(pre)
		id = pre.index(_max)
		f.write("%d, %.4f\n" % (id, _max))
		pre_id.append(id)
		pre[id] = -100

	f.close()

	id_cita = dict(zip(y_id, cita))

	return y_id, pre_id, id_cita

def TopN(y, pre, ntop, fout):
	#test_list = test
	test_list = y.copy()
	result_list = pre.copy()
	test_max = []
	test_max_id = []
	#result_list = result.tolist()
	result_max = []
	result_max_id = []
	#with open("top.txt", 'w') as f:
	#	for i in range(len(test)):
	#		f.write(str(test[i]) + '\t' + str(result[i]) + '\n')
	#fout.write("y\n")
	for i in range(ntop):
		_max = max(test_list)
		id = test_list.index(_max)
		#fout.write("%d, %.4f\n" % (id, _max))
		test_max.append(_max)
		test_max_id.append(id)
		test_list[id] = -100
	#fout.write("predict\n")
	for i in range(ntop):
		_max = max(result_list)
		id = result_list.index(_max)
		#fout.write("%d, %.4f\n" % (id, _max))
		result_max.append(_max)
		result_max_id.append(id)
		result_list[id] = -100

	test_max_id.sort()
	result_max_id.sort()
	#print test_max_id
	#print result_max_id
	
	correct = 0
	for id in result_max_id:
		if id in test_max_id:
			correct += 1
	#print correct
	#print ntop
	precision = float(correct) / ntop
	#print "total: %d" % ntop
	#print "correct: %d" % correct
	fout.write("top %d precision: %f\n" % (ntop, precision))
	print("top %d precision: %f" % (ntop, precision))
	

def evaluate(y_test, result, fout):
	fout.write("y:\n")
	for i in y_test:
		fout.write("%f\n" % i)
	fout.write("predict:\n")
	for i in result:
		fout.write("%f\n" % i)

	mse = mean_squared_error(y_test, result)
	mae = mean_absolute_error(y_test, result)
	#medae = median_absolute_error(y_test, result)
	#print("R2: %f" % r2)
	fout.write("MAE: %f\n" % mae)
	print("MAE: %f" % mae)
	#print "MSE: %f" % mse
	fout.write("RMSE: %f\n" % np.sqrt(mse))
	print("RMSE: %f" % np.sqrt(mse))
	#print("MedAE: %f" % medae

	spearman_rank(y_test, result)

	y_id, pre_id, id_cita = prepare(y_test, result)

	TopN(y_test, result, 5, fout)
	TopN(y_test, result, 10, fout)
	TopN(y_test, result, 20, fout)
	TopN(y_test, result, 30, fout)
	TopN(y_test, result, 40, fout)
	TopN(y_test, result, 50, fout)
	TopN(y_test, result, 100, fout)
