import argparse
from train import trainIters


def parse():
	parser = argparse.ArgumentParser(description='textExpansion')
	parser.add_argument('-tr', '--train', help='Train the model with corpus name')
	parser.add_argument('-ts', '--test', help='Test the model with corpus name')

	parser.add_argument('-m', '--model', help='the saved model')

	parser.add_argument('-bs', '--batch_size', type=int, default=32, help='Batch size')
	parser.add_argument('-hs', '--hidden_size', type=int, default=128, help='Hidden size in ???')
	#parser.add_argument('-vs', '--vocab_size', type=int, default=300, help='embedding size of word')
	parser.add_argument('-es', '--embed_size', type=int, default=300, help='embedding size of word')
	parser.add_argument('-dr', '--lr_decay_ratio', type=float, default=0.8, help='learning rate decay ratio')
	parser.add_argument('-de', '--lr_decay_epoch', type=int, default=2, help='learning rate decay epoch')
	parser.add_argument('-lr', '--learning_rate', type=float, default=0.01, help='Learning rate')

	parser.add_argument('-ms', '--max_sentence', type=int, default=50, help='max length of document')
	parser.add_argument('-mw', '--max_word', type=int, default=50, help='max length of sentence')

	parser.add_argument('-sd', '--save_dir', help='saved directory of model')

	args = parser.parse_args()
	return args

def run(args):
	learning_rate, lr_decay_epoch, lr_decay_ratio, hidden_size, \
		embed_size, batch_size, max_sentence, max_word, save_dir = \
			args.learning_rate, args.lr_decay_epoch, args.lr_decay_ratio, args.hidden_size, \
				args.embed_size, args.batch_size, args.max_sentence, args.max_word, args.save_dir

	if args.train:
		trainIters(args.train, learning_rate, lr_decay_epoch, lr_decay_ratio, batch_size, 
					hidden_size, embed_size, save_dir)

		


if __name__ == '__main__':
	args = parse()
	run(args)
